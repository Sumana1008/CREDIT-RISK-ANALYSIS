#Reading the dataset into R
riskdat <- read.csv(paste("C:/Users/Madhavan/Downloads/german_credit_data.csv", sep=""))
View(riskdat)

#Loading the libraries
library(Hmisc)
library(dplyr)
library(ggplot2)
library(gmodels)
#Checking the Data
head(riskdat)
tail(riskdat)
str(riskdat)
summary(riskdat)
describe(riskdat)

#Making some changes to data
colnames(riskdat)[1] <- "index"
#Splitting age into 4 groups for bettwr visualization
riskdat$age_gp<-c(0)
riskdat$age_gp<-findInterval(riskdat$Age,c(18,25,35,60,120))

################################################################################
#checking for missing values in the dataset
sum(is.na(riskdat))
colSums(is.na(riskdat)) #number of null values in each column
#tabular view
na_count <-sapply(riskdat, function(y) sum(length(which(is.na(y)))))
data.frame(na_count)
#handling missing data
# filling in the missing values using mode of the data in respective colums
riskdat$Credit.amount = ifelse(is.na(riskdat$Credit.amount),
                               ave(riskdat$Credit.amount, FUN = function (x)mean(x ,na.rm = TRUE)),
                               riskdat$Credit.amount)
tabyl(riskdat$Checking.account)
riskdat$Checking.account[is.na(riskdat$Checking.account)]<-"little"
tabyl(riskdat$Saving.accounts)
riskdat$Saving.accounts[is.na(riskdat$Saving.accounts)]<-"little"

#check again for na values
na_count <-sapply(riskdat, function(y) sum(length(which(is.na(y)))))
data.frame(na_count)
#checking for duplicate values if any
sum(duplicated(riskdat))
# unique variables 
sapply(riskdat, function(x) length(unique(x)))
################################################################################

#Some Explorations
sum(riskdat$Age==4)
# Credit Amount
hist(riskdat$Credit.amount, main = "Histogram of Credit Amount", 
     xlab = "Credit Amount", ylab = "Frequency", col = "green", border = "black")

# Sex
ggplot(riskdat, aes(Sex) ) + geom_bar(aes(fill = as.factor(riskdat$Sex))) + 
  scale_fill_discrete(name="Sex",
                      labels=c( "Female","Male")) + 
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) +
  labs(x= "Sex",y= "Frequency" , title = "Bar Plot of Sex")

# Job type
ggplot(riskdat, aes(Job) ) + geom_bar(aes(fill = as.factor(riskdat$Job))) + 
  scale_fill_discrete(name="Job Type",
                      labels=c( "Unskilled and Non-Resident","Unskilled and Resident", "Skilled", "Highly Skilled")) + 
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) +
  labs(x= "Level of Job",y= "Frequency" , title = "Bar Plot of Job")

#Age Not Working
ggplot(riskdat, aes(age_gp) ) + geom_bar(aes(fill = as.factor(riskdat$age_gp))) + 
  scale_fill_discrete(name="Age Catogory",
                      labels=c( "Student","Young Adult","Middle-Aged Adult", "Senior")) + 
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) +
  labs(x= "Level of Job",y= "Frequency" , title = "Bar Plot of Age")

# Housing
ggplot(riskdat, aes(Housing) ) + geom_bar(aes(fill = as.factor(riskdat$Housing))) + 
  scale_fill_discrete(name="Housing",
                      labels=c( "Free","Own", "Rent")) + 
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) +
  labs(x= "Housing",y= "Frequency" , title = "Bar Plot of Housing")

# Saving Accounts
ggplot(riskdat, aes(Saving.accounts) ) + geom_bar(aes(fill = as.factor(riskdat$Saving.accounts)))  + 
  scale_fill_discrete(name="Saving Accounts",
                      labels=c( "Little","Moderate", "Quite Rich", "Rich", "NA"))  +
  labs(x= "Saving Accounts",y= "Frequency" , title = "Bar Plot of Saving Accounts")

#Checking Account
ggplot(riskdat, aes(Checking.account) ) + geom_bar(aes(fill = as.factor(riskdat$Checking.account))) + 
  scale_fill_discrete(name="Checking Account",
                      labels=c( "Little","Moderate", "Rich")) + 
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) +
  labs(x= "Checking Account",y= "Frequency" , title = "Bar Plot of Checking Account")

# Duration
ggplot(riskdat, aes(Duration)) + geom_histogram(binwidth=4, colour="black", fill="blue") +
  labs(x= "Duration in Months",y= "Frequency" , title = "Histogram of Duration")

# Purpose
ggplot(riskdat, aes(Purpose) ) + geom_bar(aes(fill = as.factor(riskdat$Purpose))) + 
  scale_fill_discrete(name="Purpose of Loan",labels=c( "Business","Car", "Domestic Appliances","Education","Furniture/Equipment","Radio/TV","Repairs","Vacation/Others")) + 
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) +
  labs(x= "Purpose of Loan",y= "Frequency" , title = "Bar Plot of Loan Purpose")


################################################################################

#Reading the dataset into R
riskdat <- read.csv(paste("C:/Users/Madhavan/Downloads/german_credit_data.csv", sep=""))
View(riskdat)

#Loading the libraries
library(Hmisc)
library(dplyr)
library(ggplot2)
library(gmodels)
#Checking the Data
head(riskdat)
tail(riskdat)
str(riskdat)
summary(riskdat)
describe(riskdat)

#Making some changes to data
colnames(riskdat)[1] <- "index"
#Splitting age into 4 groups for bettwr visualization
riskdat$age_gp<-c(0)
riskdat$age_gp<-findInterval(riskdat$Age,c(18,25,35,60,120))
str(riskdat)

#Some important changes to be made in the data
riskdat$Sex_up<-c(0)
riskdat$Sex_up[which(riskdat$Sex=="male")]<-c(1)
riskdat$Sex_up[which(riskdat$Sex=="female")]<-c(2)

riskdat$housing_up<-c(0)
riskdat$housing_up[which(riskdat$Housing=="own")]<-c(1)
riskdat$housing_up[which(riskdat$Housing=="free")]<-c(2)
riskdat$housing_up[which(riskdat$Housing=="rent")]<-c(3)

riskdat$Sav_up<-c(0)
riskdat$Sav_up[which(riskdat$Saving.accounts=="little")]<-c(1)
riskdat$Sav_up[which(riskdat$Saving.accounts=="moderate")]<-c(2)
riskdat$Sav_up[which(riskdat$Saving.accounts=="quite rich")]<-c(3)
riskdat$Sav_up[which(riskdat$Saving.accounts=="rich")]<-c(4)

riskdat$rs_up<-c(0)
riskdat$rs_up[which(riskdat$Risk=="good")]<-c(1)
riskdat$rs_up[which(riskdat$Risk=="bad")]<-c(0)

riskdat$ch_ac<-c(0)
riskdat$ch_ac[which(riskdat$Checking.account=="little")]<-c(1)
riskdat$ch_ac[which(riskdat$Checking.account=="moderate")]<-c(2)
riskdat$ch_ac[which(riskdat$Checking.account=="rich")]<-c(3)

riskdat$pu_up<-c(0)
riskdat$pu_up[which(riskdat$Purpose=="radio/TV")]<-c(1)
riskdat$pu_up[which(riskdat$Purpose=="education")]<-c(2)
riskdat$pu_up[which(riskdat$Purpose=="furniture/equipment")]<-c(3)
riskdat$pu_up[which(riskdat$Purpose=="car")]<-c(4)
riskdat$pu_up[which(riskdat$Purpose=="business")]<-c(5)
riskdat$pu_up[which(riskdat$Purpose=="domestic appliances")]<-c(6)
riskdat$pu_up[which(riskdat$Purpose=="repairs")]<-c(7)
riskdat$pu_up[which(riskdat$Purpose=="vacation/others")]<-c(8)

#Some important inferences
#RISK
ggplot(riskdat, aes(Risk) ) + geom_bar(aes(fill = as.factor(riskdat$Risk))) + 
  scale_fill_discrete(name="Risk",
                      labels=c( "good", "bad")) + 
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) + labs(x= "Risk",y= "Frequency" , title = "Plot of Risk")



boxplot(riskdat$Credit.amount~riskdat$age_gp,horizontal=TRUE,ylab="Age Group",
        xlab="credit amount",las=1,main="Credit amount v/s Age group",col=c("red","green","pink","yellow"),
        names=c( "Student","Young Adult","Middle-Aged Adult", "Senior"))
#it can be seen that middle aged and young adults take the most amount of credit

#HOUSING 1=OWN 2=FREE 3=RENT
histogram(Credit.amount~housing_up|Risk,data=riskdat)
#It can be seen that there is high correlation between good risk and people who own houses.

boxplot(Credit.amount~Housing+Risk,data=riskdat,horizontal=TRUE,xlab="Distribution of Housing by credit amount")
#it can be seen that the highest values come from category "free".

#SEX 1=MALE 2=FEMALE
histogram(Credit.amount~Sex_up|Risk,data=riskdat)

boxplot(Credit.amount~Sex+Risk,data=riskdat,horizontal=TRUE,xlab="Distribution of credit amount by sex")

#JOB 0=Unskilled and Non-Resident 1=Unskilled and Resident   2=Skilled 3=Highly Skilled
histogram(Credit.amount~Job|Risk,data=riskdat)

boxplot(Credit.amount~Job+Risk,data=riskdat,horizontal=TRUE,xlab="Distribution of Job by credit amount")

mytab1<-xtabs(~Risk+Job,data=riskdat)
mytab1

#PURPOSE 1=RADIO/TV 2=EDUCATION 3=FURNITURE/EQUIPMENT 4=CAR 5=BUSINESS
# 6=DOMESTIC APLLIANCES  7=REPAIRS 8=VACATION/OTHERS
histogram(Credit.amount~pu_up|Risk,data=riskdat)

boxplot(Credit.amount~Purpose+Risk,data=riskdat,horizontal=TRUE,xlab="Distribution of Purpose by credit amount")

mytab<-xtabs(~Risk+Purpose,data=riskdat)
mytab

histogram(Risk~pu_up,data=riskdat)

boxplot(Credit.amount~Purpose+Risk,data=riskdat,horizontal=TRUE,xlab="Distribution of Housing by credit amount",col=c("red","yellow"))

boxplot(Duration~Risk+Credit.amount,data=riskdat,horizontal=TRUE,xlab="Distribution of Housing by credit amount")

#It can be clearly seen that the highest duration have the highest amount The highest density is between [12~18~24] months.

#Some important contingency tables. They displays the (multivariate) frequency distribution of the variables.
#They provide a basic picture of the interrelation between two variables and can help find interactions between them.
mytable_ch<-with(riskdat,table(Checking.account))
mytable_ch

mytable_js<-xtabs(~Job+Sex,data=riskdat)
mytable_js

mytable_cs<-xtabs(~Checking.account+Sex,data=riskdat)
mytable_cs

mytable_sp<-xtabs(~Sex+Purpose,data=riskdat)
mytable_sp

#Correlation in the data
cor(riskdat[,c(1,4,8,9,12:18)])
library(corrplot)
corrplot(corr=cor(riskdat[,c(1,4,8,9,12:18)]),method="ellipse")
#Extracting missing values
miss= apply(X= riskdat, MARGIN = 2, FUN = function(k) which(is.na(k) | is.nan(k) | is.infinite(k)))

#removing missing values
misspos  = sort(unique(unlist(miss, use.names=FALSE)))
riskdat1 = riskdat[-misspos,]
nrow(riskdat1)

#Since,the response variable(Risk-good or Bad) is binary, it is preferred to use Logistic regression instead of linear.
str(riskdat)
#Model
mylogit=rs_up~Sex+Saving.accounts+Checking.account+Duration+Purpose+Job+Housing+Age
fit=glm(mylogit,data=riskdat,family = binomial(link= "logit"))
summary(fit)
#Confidence interval for the coefficients Beta_hat
confint(fit)

#Confusion Matrix
pred=predict(fit,type="response")
summary(pred)
table(riskdat1$Risk,round(pred))
#The table above shows that the model predicted 125 bad and 230 good Risk correctly. and 106 bad and 61 good Risk incorrectly.
#Calculating the accuracy of the model
y=ifelse(riskdat1$Risk=="bad",0,1)
fitted.results <- ifelse(pred > 0.5,1,0)
CrossTable(fitted.results)

misClasificError <- mean(fitted.results != y)
Acc=1-misClasificError
print(Acc)
#The fitted model is 68.00% accurate.

### Effectiveness of the model using various indicator tests

#Pseudo R-Squared(MacFadden Test)
# McFadden test =(1 log likelihood of fitted model/log likelihood of null model)
library(pscl)
pR2(fit)
#Since the value of McFadden is 0.4795 (>0.3), the model is a good fit to the data.

#Roc Curve
library(ROCR)
pred=predict(fit,type="response")
pr <- prediction(pred, riskdat1$Risk)
prf <- performance(pr, measure = "tpr", x.measure = "fpr")
plot(prf)
#Area Under the Curve (AUC)
auc <- performance(pr, measure = "auc")
auc <- auc@y.values[[1]]
auc

#Tjur's R squared
#Tjur's R squared has an appealing intuitive definition. For all of the 
#observed 0s in the data table, calculate the mean predicted value. Similarly, 
#for all of the observed 1s in the data table, calculate that mean predicted value.
#Tjur's R squared is the distance (absolute value of the difference) between the 
#two means. Thus, a Tjur's R squared value approaching 1 indicates that there is 
#clear separation between the predicted values for the 0s and 1s. Additionally, 
#Tjur's R squared (like R squared in linear regression) is actually bound between 0 and 1.

#Tjur's R squared = |Average Predicted value for 0s - Average Predicted value for 1s|
#Tjur Statistic
tjur= mean(pred[which(y==1)])-mean(pred[which(y==0)])
tjur

#The value of TJUR statistic reveals that the model is a moderate fit to the data.


